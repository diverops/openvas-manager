Report Format Plugin "Vernice ISM"

This plugin was originally developed for use
with Greenbone Security Manager. It is fully compatible
with OpenVAS, but some variable names and tag use
the abbreviation "gsm".
These are required by Verinice, a Open Source ISMS-Tool
avaiable from www.verinice.org
